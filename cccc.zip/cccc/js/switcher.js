google.load("jquery", "1.3.1");
google.setOnLoadCallback(function()
{
    // Apply some CSS3 to keep the CSS file CSS 2.1 valid
    $("h1").css("text-shadow", "0px 2px 6px #000");
    $("h2 a").css("text-shadow", "0px 2px 6px #000");

    // Color changer
    $(".charcoal").click(function(){
        $("link").attr("href", "css/charcoal.css");
        return false;
    });
    $(".chocolate").click(function(){
        $("link").attr("href", "css/chocolate.css");
        return false;
    });
    $(".coffee").click(function(){
        $("link").attr("href", "css/coffee.css");
        return false;
    });
    $(".forest").click(function(){
        $("link").attr("href", "css/forest.css");
        return false;
    });
    $(".midnight").click(function(){
        $("link").attr("href", "css/midnight.css");
        return false;
    });
    $(".olive").click(function(){
        $("link").attr("href", "css/olive.css");
        return false;
    });
    $(".plum").click(function(){
        $("link").attr("href", "css/plum.css");
        return false;
    });
    $(".silver").click(function(){
        $("link").attr("href", "css/silver.css");
        return false;
    });
    $(".steelblue").click(function(){
        $("link").attr("href", "css/steelblue.css");
        return false;
    });
    $(".violet").click(function(){
        $("link").attr("href", "css/violet.css");
        return false;
    });
});